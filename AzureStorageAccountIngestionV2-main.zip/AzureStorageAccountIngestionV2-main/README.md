# Ingest from Azure Storage Account
This custom Microsoft Sentinel Data connector ingests Azure Storage Account Blobs to Microsoft Sentinel

## **Deployment**

1. Click on Deploy to Azure (For both Commercial & Azure GOV)  
   <a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fsreedharande%2FAzureStorageAccountIngestionV2%2Fmain%2Fazuredeploy.json" target="_blank">
    <img src="https://aka.ms/deploytoazurebutton"/>
	</a>
  

